---



copyright:
  years: 2018
lastupdated: "2018-01-24"


---

{:shortdesc: .shortdesc}
{:codeblock: .codeblock}
{:screen: .screen}
{:new_window: target="_blank"}
{:pre: .pre}
{:table: .aria-labeledby="caption"}

# 5. Testing connectivity to your IBM Cloud data center
{: #test_connectivity}

{{site.data.keyword.cloud}} provides a speed test that you can use to test your download, upload, and latency speeds. The URL is https://speedtest.xxxxx.softlayer.com/speedtest; replace the "xxxxx" with your data center. For example, if your data center is DAL07, your URL is http://speedtest.dal07.softlayer.com/speedtest/. You can scroll to the bottom of the [data center page](https://www.ibm.com/cloud-computing/bluemix/data-centers) page for the exact URL for each {{site.data.keyword.cloud_notm}} global data center.
