# sap-hana
sap-hana

SMEs:

OM - Bradley Knapp, Bradley Knapp/US/IBM

SME - Rainer Vetter, rainer.vetter@de.ibm.com

Ingo Dahm, ingo.dahm@palmarium-itc.com

OM - Wolfgang Knobloch, wolfgang.knobloch@de.ibm.com
